﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using NavigateAway.Annotations;
using NavigateAway.Model;
using NavigateAway.View;
using Admin = NavigateAway.Model.Admin;
using User = NavigateAway.Model.User;

namespace NavigateAway.ViewModel
{
    class ViewModel : INotifyPropertyChanged
    {
        private string _text;
        private ObservableCollection<Admin> _admins;
        private ObservableCollection<User> _users;

        public ViewModel()
        {
            _admins = new ObservableCollection<Admin>();
           AdminList();

            _users = new ObservableCollection<User>();
           UserList();
           
        }


        #region Admin

        public string UserName { get; set; }
        public string Password { get; set; }

        public string Text
        {
            get => _text;
            set
            {
                _text = value;
                OnPropertyChanged("Text");
            }
            
        }

        public ObservableCollection<Admin> Admins
        {
            get => _admins;
            set => _admins = value;
        }

        public void AdminList()
        {
            if (_admins.Count == 0)
            {
                Admin admin1 = new Admin("Admin", "Admin");
                _admins.Add(admin1);
            }
        }

        public void Check()
        {
            foreach (Admin admin in _admins)
            {
                if (admin.UserName == UserName && admin.Password == Password)
                {
                    ((Frame) Window.Current.Content).Navigate(typeof(MyAdminPage));
                }
            }

            Text = "Admin not found";
        }

        #endregion


        #region User

        public static string xUsername { get; set; }
        public static string xPassWord { get; set; }

        public static string firstName { get; set; }
        public static string lastName { get; set; }
        public static string phonenumber { get; set; }
        public static string email { get; set; }



        public ObservableCollection<User> Users
        {
            get => _users;
            set => _users = value;
        }

        public void UserList()
        {
            if (_users.Count == 0)
            {
                User HelenaG = new User("HelenaG", "helena", "Helena", "Graff", "28580211", "helenagraff@hotmail.com");
                _users.Add(HelenaG);

                User Filip = new User("FilipH", "filip", "Filip", "Dan Hansen", "30329194", "fdhsport@gmail.com");
                _users.Add(Filip);

                User HelenaS = new User("HelenaS", "helenas", "Helena", "Skjaldgaard Rasmussen", "23493388", "helena-rasmussen@hotmail.com");
                _users.Add(HelenaS);

                User Anja = new User("AnjaF", "anja", "Anja", "Fausing Wilstrup Sundebo", "53545332", "futhark1536@gmail.com");
                _users.Add(Anja);
            }

            
        }

        public void CheckUser()
        {
            foreach (User user in _users)
            {
                if (user.username == xUsername && user.password == xPassWord)
                {
                    firstName = user.firstName;
                    lastName = user.lastName;
                    phonenumber = user.phonenumber;
                    email = user.email;
                    ((Frame)Window.Current.Content).Navigate(typeof(MyPage));
                }

            }

            Text = "User not found";
        }


        #endregion


        #region Destination

        public string Destination { get; set; }
        public string Price { get; set; }


        public ViewModel(string destination, string price)
        {
            Destination = destination;
            Price = price;
        }



        #endregion





        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
