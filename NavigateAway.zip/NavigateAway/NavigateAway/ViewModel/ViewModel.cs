﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using NavigateAway.Annotations;

namespace NavigateAway.ViewModel
{
    class ViewModel : INotifyPropertyChanged
    {

        public string Destination { get; set; }
        public string Price { get; set; }


        public ViewModel(string destination, string price)
        {
            Destination = destination;
            Price = price;
        }


        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
