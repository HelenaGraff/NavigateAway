﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NavigateAway.Model;

namespace NavigateAway.ViewModel
{
    class UserSingleton
    {
        private static UserSingleton _instance = new UserSingleton();

        public static UserSingleton Instance
        {
            //get
            //{
            //    if (_instance == null)
            //        _instance = new EventCatalogSingleton();
            //    return _instance;
            //}

            get { return _instance ?? (_instance = new UserSingleton()); }

        }

        public ObservableCollection<User> Users { get; set; }

        private UserSingleton()
        {
            Users = new ObservableCollection<User>();
            //LoadUsersAsync();
        }



        //public async void LoadUsersAsync()
        //{
        //    var users = await PersistencyService.LoadUsersFromJsonAsync();
        //    if (users != null)
        //        foreach (var user in Users)
        //        {
        //            Users.Add(user);
        //        }
        //    else
        //    {
        //        //Data til testformål
        //        Users.Add(new User(1, "Pitching 2end semester Projects", "Auditorium 202", new DateTime(2014, 12, 24, 9, 0, 0), "De studerende fremlægger deres eksamensprojekt"));
        //        Users.Add(new User(2, "Eksamen", "lokale 122", new DateTime(2015, 1, 6, 9, 0, 0), "Eksamen 1. semester"));
        //    }
        //}



        public void Add(User newEvent)
        {
            Users.Add(newEvent);
            PersistencyService.SaveEventsAsJsonAsync(Users);
        }

        public void Add(int id, string name, string place, DateTime dateTime, string description)
        {
            Users.Add(new User(id, name, place, dateTime, description));
            PersistencyService.SaveEventsAsJsonAsync(Users);
        }

        public void Remove(User eventToBeRemoved)
        {
            Users.Remove(eventToBeRemoved);
            PersistencyService.SaveEventsAsJsonAsync(Users);
        }

    }
}
    

