﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace NavigateAway.Model
{
    class TravelDestinations
    {
        public int Indeks { get; set; }
        public int ID { get; set; }
        public double Price { get; set; }
        public string Location { get; set; }

        public TravelDestinations(int id, double price, string location)
        {
            ID = id;
            Price = price;
            Location = location;
        }

        public override string ToString()
        {
            return $"{nameof(ID)}: {ID}, {nameof(Price)}: {Price}, {nameof(Location)}: {Location}";
        }
    }

    class DestinationList
    {
        public ObservableCollection<TravelDestinations> MyDestination = new ObservableCollection<TravelDestinations>();
        private Random numberGenerator;

        public void SetupDestination()
        {
            numberGenerator = new Random();

            //Italy
            TravelDestinations destination1 = new TravelDestinations(numberGenerator.Next(10000, 99999), 4300, "Rome, Italy");
            MyDestination.Add(destination1);

            TravelDestinations destination2 = new TravelDestinations(numberGenerator.Next(10000, 99999), 2300, "Verona, Italy");
            MyDestination.Add(destination2);

            TravelDestinations destination3 = new TravelDestinations(numberGenerator.Next(10000, 99999), 5000, "Milan, Italy");
            MyDestination.Add(destination3);

            TravelDestinations destination4 = new TravelDestinations(numberGenerator.Next(10000, 99999), 3600, "Florence, Italy");
            MyDestination.Add(destination4);

            //Egypt
            TravelDestinations destination5 = new TravelDestinations(numberGenerator.Next(10000, 99999), 6000, "Sharm El Sheikh, Egypten");
            MyDestination.Add(destination5);

            TravelDestinations destination6 = new TravelDestinations(numberGenerator.Next(10000, 99999), 2300, "Hurghada Egypt");
            MyDestination.Add(destination6);

            TravelDestinations destination7 = new TravelDestinations(numberGenerator.Next(10000, 99999), 2300, "Cairo, Egypt");
            MyDestination.Add(destination7);

            //France
            TravelDestinations destination8 = new TravelDestinations(numberGenerator.Next(10000,99999), 15000, "Paris, France");
            MyDestination.Add(destination8);

            TravelDestinations destination9 = new TravelDestinations(numberGenerator.Next(10000, 99999), 4800, "Nice, France");
            MyDestination.Add(destination9);

            TravelDestinations destination10 = new TravelDestinations(numberGenerator.Next(10000, 99999), 6700, "Marseille, France");
            MyDestination.Add(destination10);

            TravelDestinations destination11 = new TravelDestinations(numberGenerator.Next(10000, 99999), 7800, "Val Thorens, France");
            MyDestination.Add(destination11);

            //Portugal 
            TravelDestinations destination12 = new TravelDestinations(numberGenerator.Next(10000, 99999), 6200, "Lissabon, Portugal");
            MyDestination.Add(destination12);

            TravelDestinations destination13 = new TravelDestinations(numberGenerator.Next(10000, 99999), 5400, "Porto, Portugal");
            MyDestination.Add(destination13);

            //Japan
            TravelDestinations destination14 = new TravelDestinations(numberGenerator.Next(10000, 99999), 8750, "Tokyo, Japan");
            MyDestination.Add(destination14);

            TravelDestinations destination15 = new TravelDestinations(numberGenerator.Next(10000, 99999), 9000, "Hiroshima, Japan");
            MyDestination.Add(destination15);
        }

        public void AddTravel(double price, string location)
        {
            TravelDestinations newDestinations = new TravelDestinations(numberGenerator.Next(10000, 99999), price, location);

            MyDestination.Add(newDestinations);

        }

        public void RemoveTravel(int indeks)
        {
            MyDestination.RemoveAt(indeks);
        }


       
    }
}
