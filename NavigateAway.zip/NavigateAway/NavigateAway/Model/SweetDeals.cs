﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NavigateAway.Model
{
    class SweetDeals
    {
        public string Destination { get; set; }
        public int Price { get; set; }


        public SweetDeals(string destination, int price)
        {
            this.Destination = destination;
            this.Price = price;
        }

        public override string ToString()
        {
            return $"{nameof(Destination)}: {Destination}, {nameof(Price)}: {Price}";
        }
    }
}
