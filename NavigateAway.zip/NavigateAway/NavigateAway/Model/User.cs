﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using NavigateAway.Annotations;
using NavigateAway.View;

namespace NavigateAway.Model
{
    class User
    {
        //Things being checked during login
        public string username { get; set; }
        public string password { get; set; }

        //Personal data
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phonenumber { get; set; }
        public string email { get; set; }

        public User(string username, string password, string firstName, string lastName, string phonenumber, string email)
        {
            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.phonenumber = phonenumber;
            this.email = email;
        }

        public override string ToString()
        {
            return $"{nameof(username)}: {username}, {nameof(password)}: {password}, {nameof(firstName)}: {firstName}, {nameof(lastName)}: {lastName}, {nameof(phonenumber)}: {phonenumber}, {nameof(email)}: {email}";
        }
    }

    class UserList : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}


