﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using NavigateAway.Annotations;
using NavigateAway.View;

namespace NavigateAway.Model
{
    class Admin
    {
        //Things being checked during login
        public string userName { get; set; }
        public string password { get; set; }

        public Admin(string userName, string password)
        {
            this.userName = userName;
            this.password = password;
        }

        public override string ToString()
        {
            return $"{nameof(userName)}: {userName}, {nameof(password)}: {password}";
        }
    }

    class adminList : INotifyPropertyChanged
    {
        private string _text;
        private static ObservableCollection<Admin> _admins = new ObservableCollection<Admin>();

        public string userName { get; set; }
        public string password { get; set; }

        public string text
        {
            get => _text;
            set
            {
                _text = value;
                OnPropertyChanged("text");
            }
        }

        public ObservableCollection<Admin> Admins
        {
            get => _admins;
            set => _admins = value;
        }

        public adminList()
        {
            if (_admins.Count == 0)
            {
                Admin admin1 = new Admin("Admin", "Admin");
                _admins.Add(admin1);
            }
        }

        public void Check()
        {
            foreach (Admin admin in _admins)
            {
                if (admin.userName == userName && admin.password == password)
                {
                    ((Frame)Window.Current.Content).Navigate(typeof(MyAdminPage));
                }
            }

            text = "Admin not found";
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        }
    }
}
